'use client';

import React, { useEffect } from 'react';

export default function Skills() {
  useEffect(() => {
    const rings = document.querySelectorAll('.skill-ring');
    const R = 30, C = 2 * Math.PI * R;
    const animateRing = (el: Element) => {
      const pct = parseInt((el as HTMLElement).dataset.pct || '80', 10);
      const fg = el.querySelector('.ring-fg') as SVGElement;
      if (fg) {
        const offset = C - (pct / 100) * C;
        requestAnimationFrame(() => {
          fg.style.strokeDashoffset = String(offset);
        });
      }
    };

    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          animateRing(e.target);
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.4 });

    rings.forEach(r => io.observe(r));

    const catBtns = document.querySelectorAll('.skill-cat-btn');
    const handleCatClick = (e: Event) => {
      const btn = e.currentTarget as HTMLElement;
      catBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.cat;
      rings.forEach(r => {
        (r as HTMLElement).style.display = (cat === 'all' || (r as HTMLElement).dataset.cat === cat) ? '' : 'none';
      });
    };

    catBtns.forEach(btn => btn.addEventListener('click', handleCatClick));

    return () => {
      io.disconnect();
      catBtns.forEach(btn => btn.removeEventListener('click', handleCatClick));
    };
  }, []);

  return (
    <section id="skills">
      <div className="wrap">
        <div className="sec-head">
          <div><div className="eyebrow">Skills</div><h2 style={{ marginTop: '8px' }}>What I reach for, and how often.</h2></div>
          <p>Filter by category to see depth and breadth of technical stack.</p>
        </div>
        <div className="skill-cats" id="skillCats">
          <div className="skill-cat-btn active" data-cat="all">All</div>
          <div className="skill-cat-btn" data-cat="ml">Full-Stack &amp; AI</div>
          <div className="skill-cat-btn" data-cat="infra">Systems &amp; Infra</div>
          <div className="skill-cat-btn" data-cat="lang">Languages</div>
        </div>
        <svg width="0" height="0"><defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#2554ff"/><stop offset="100%" stopColor="#22d3ee"/></linearGradient></defs></svg>
        <div className="skill-grid" id="skillGrid">
          <div className="skill-ring" data-cat="lang" data-pct="92"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">92%</div><div className="name">Python</div></div>
          <div className="skill-ring" data-cat="ml" data-pct="90"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">90%</div><div className="name">FastAPI</div></div>
          <div className="skill-ring" data-cat="ml" data-pct="88"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">88%</div><div className="name">Next.js</div></div>
          <div className="skill-ring" data-cat="lang" data-pct="85"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">85%</div><div className="name">TypeScript</div></div>
          <div className="skill-ring" data-cat="ml" data-pct="90"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">90%</div><div className="name">Tailwind</div></div>
          <div className="skill-ring" data-cat="infra" data-pct="80"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">80%</div><div className="name">PostgreSQL</div></div>
          <div className="skill-ring" data-cat="infra" data-pct="78"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">78%</div><div className="name">Docker</div></div>
          <div className="skill-ring" data-cat="infra" data-pct="85"><svg viewBox="0 0 76 76"><circle className="ring-bg" cx="38" cy="38" r="30"/><circle className="ring-fg" cx="38" cy="38" r="30" strokeDasharray="188.5" strokeDashoffset="188.5"/></svg><div className="pct">85%</div><div className="name">Git</div></div>
        </div>
      </div>
    </section>
  );
}

'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';

interface Technology {
  id: number;
  name: string;
}

interface Project {
  id: number;
  title: string;
  slug: string;
  summary: string;
  year: number;
  thumbnail_url?: string;
  github_url?: string;
  demo_url?: string;
  is_featured: boolean;
  technologies?: Technology[];
}

export default function ProjectsSection() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProjects() {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
      try {
        const res = await fetch(`${apiUrl}/api/v1/projects?status=published`);
        if (res.ok) {
          const data = await res.json();
          setProjects(data);
        }
      } catch (error) {
        console.error('Error fetching projects:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchProjects();
  }, []);

  useEffect(() => {
    const schemes: Record<string, string[]> = {
      blue:  ['#2554ff','#c7d2fe'],
      cyan:  ['#22d3ee','#bef8ff'],
      indigo:['#6366f1','#ddd6fe']
    };
    const canvases = document.querySelectorAll('.p-canvas') as NodeListOf<HTMLCanvasElement>;
    const animIds: number[] = [];

    canvases.forEach((canvas, idx) => {
      const schemeKeys = Object.keys(schemes);
      const scheme = schemes[schemeKeys[idx % schemeKeys.length]];
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = parent.clientWidth * dpr;
      canvas.height = parent.clientHeight * dpr;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const pts = Array.from({length:20}, () => ({
        x: Math.random()*canvas.width, y: Math.random()*canvas.height,
        vx:(Math.random()-0.5)*0.4, vy:(Math.random()-0.5)*0.4
      }));

      let animId = 0;
      function draw(){
        if (!ctx) return;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        pts.forEach(p => {
          p.x += p.vx; p.y += p.vy;
          if (p.x<0||p.x>canvas.width) p.vx*=-1;
          if (p.y<0||p.y>canvas.height) p.vy*=-1;
        });
        for (let i=0;i<pts.length;i++){
          for (let j=i+1;j<pts.length;j++){
            const dx=pts[i].x-pts[j].x, dy=pts[i].y-pts[j].y;
            const d = Math.sqrt(dx*dx+dy*dy);
            if (d < canvas.width*0.18){
              ctx.strokeStyle = scheme[0]; ctx.globalAlpha = (1 - d/(canvas.width*0.18))*0.35;
              ctx.beginPath(); ctx.moveTo(pts[i].x,pts[i].y); ctx.lineTo(pts[j].x,pts[j].y); ctx.stroke();
            }
          }
        }
        ctx.globalAlpha = 1;
        pts.forEach(p => {
          ctx.fillStyle = scheme[1];
          ctx.beginPath(); ctx.arc(p.x,p.y,2.2*dpr,0,Math.PI*2); ctx.fill();
        });
        animId = requestAnimationFrame(draw);
      }
      draw();
      animIds.push(animId);
    });

    return () => {
      animIds.forEach(id => cancelAnimationFrame(id));
    };
  }, [projects]);

  return (
    <section id="work">
      <div className="wrap">
        <div className="sec-head">
          <div><div className="eyebrow">Selected Work</div><h2 style={{ marginTop: '8px' }}>Projects worth a second look.</h2></div>
          <p>A mix of full-stack apps, AI tools, and technical systems built with robust architecture.</p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-400">Loading projects...</div>
        ) : projects.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-[var(--border)] p-8">
            <p className="font-medium text-[var(--ink-soft)]">No published projects available yet.</p>
          </div>
        ) : (
          <div className="proj-grid">
            {projects.slice(0, 6).map((project, idx) => (
              <div key={project.id} className="proj-card">
                <div className="proj-visual" style={{ background: idx % 2 === 0 ? 'linear-gradient(135deg,#dbe3ff,#eef1ff 60%)' : 'linear-gradient(135deg,#e3fbff,#eef1ff 60%)' }}>
                  <canvas className="p-canvas" data-scheme={idx % 2 === 0 ? 'blue' : 'cyan'} style={{ width: '100%', height: '100%' }}></canvas>
                  <span className="idx mono">0{idx + 1}</span>
                </div>
                <h3>{project.title}</h3>
                <p>{project.summary}</p>
                {project.technologies && project.technologies.length > 0 && (
                  <div className="proj-tags">
                    {project.technologies.map((tech) => (
                      <span key={tech.id} className="tag">{tech.name.toUpperCase()}</span>
                    ))}
                  </div>
                )}
                <div className="proj-links">
                  <Link href={`/projects/${project.slug}`}>Case Study →</Link>
                  {project.github_url && (
                    <a href={project.github_url} target="_blank" rel="noreferrer">Source →</a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

'use client';

import React, { useState } from 'react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    sender_name: '',
    sender_email: '',
    subject: 'General Inquiry',
    message: ''
  });
  const [status, setStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: null, message: '' });

    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

    try {
      const res = await fetch(`${apiUrl}/api/v1/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (res.ok) {
        setStatus({ type: 'success', message: 'Message sent successfully! Thank you for reaching out.' });
        setFormData({ sender_name: '', sender_email: '', subject: 'General Inquiry', message: '' });
      } else {
        setStatus({ type: 'error', message: data.detail || 'Failed to send message. Please try again.' });
      }
    } catch {
      setStatus({ type: 'error', message: 'Network error. Please check if backend is running.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contact-outer">
      <div id="contact">
        <div className="contact-grid">
          <div>
            <div className="eyebrow" style={{ color: '#9aa0ad' }}>Contact</div>
            <h2 style={{ marginTop: '10px' }}>Let&apos;s build something that has to actually work.</h2>
            <p className="lead">Open to full-stack roles, web projects, and select advisory work. Fastest way to reach me is email.</p>
            <div className="status-badge">Open to new projects — 2026</div>
            <div className="social-row">
              <a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub">GH</a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">IN</a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="X">X</a>
              <a href="mailto:zaid@helsinki.com" aria-label="Email">@</a>
            </div>
          </div>
          <form className="contact-form" id="contactForm" onSubmit={handleSubmit}>
            {status.type && (
              <div className={`mb-4 p-3 rounded text-xs ${status.type === 'success' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800' : 'bg-rose-950/60 text-rose-300 border border-rose-800'}`}>
                {status.message}
              </div>
            )}
            <div className="field">
              <label>Name</label>
              <input
                type="text"
                id="cName"
                placeholder="Your name"
                required
                value={formData.sender_name}
                onChange={e => setFormData({ ...formData, sender_name: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Email</label>
              <input
                type="email"
                id="cEmail"
                placeholder="you@company.com"
                required
                value={formData.sender_email}
                onChange={e => setFormData({ ...formData, sender_email: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Message</label>
              <textarea
                rows={4}
                id="cMsg"
                placeholder="What are you building?"
                required
                value={formData.message}
                onChange={e => setFormData({ ...formData, message: e.target.value })}
              ></textarea>
            </div>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? 'Sending...' : 'Send message →'}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

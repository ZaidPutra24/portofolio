import React from 'react';

export default function Navbar() {
  return (
    <nav id="nav">
      <div className="brand"><span></span>zaid helsinki</div>
      <div className="nav-links" id="navLinks">
        <a href="#work" className="active">Work</a>
        <a href="#about">About</a>
        <a href="#experience">Experience</a>
        <a href="#skills">Skills</a>
      </div>
      <a href="#contact" className="nav-cta">Contact →</a>
    </nav>
  );
}

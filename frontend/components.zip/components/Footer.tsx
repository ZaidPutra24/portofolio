'use client';

import React from 'react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer>
      <div className="f-copy mono">© {new Date().getFullYear()} ZAID HELSINKI. BUILT WITH INTENT.</div>
      <div className="back-top" onClick={scrollToTop}>Back to top ↑</div>
    </footer>
  );
}

'use client';

import React, { useEffect } from 'react';

const experiences = [
  {
    period: "2024 — 2025",
    title: "Lead Organizer & Director",
    company: "MUHADOROH KUBRO",
    description: "Led and directed a major annual institutional event, managing cross-functional teams, logistics, public speaking coordination, and stakeholder communications."
  },
  {
    period: "2023 — 2024",
    title: "Head of Da'wah Division",
    company: "RABITUTTULLAB ALMA'HAD",
    description: "Directed community engagement programs, social outreach initiatives, and organizational communications across student bodies."
  },
  {
    period: "2023 — Present",
    title: "Full-Stack Developer & Designer",
    company: "INDEPENDENT PROJECTS",
    description: "Developing modern web applications, portfolios, and custom REST APIs utilizing Python, FastAPI, TypeScript, Next.js, and Tailwind CSS."
  }
];

export default function Experience() {
  useEffect(() => {
    const toggles = document.querySelectorAll('.t-toggle');
    const handleToggle = (e: Event) => {
      const btn = e.currentTarget as HTMLElement;
      btn.closest('.t-item')?.classList.toggle('open');
    };
    toggles.forEach(btn => btn.addEventListener('click', handleToggle));
    return () => {
      toggles.forEach(btn => btn.removeEventListener('click', handleToggle));
    };
  }, []);

  return (
    <section id="experience">
      <div className="wrap">
        <div className="sec-head">
          <div><div className="eyebrow">Experience</div><h2 style={{ marginTop: '8px' }}>Where leadership &amp; code meet.</h2></div>
          <p>Click a role to expand details on responsibilities and impact.</p>
        </div>
        <div className="timeline" id="timeline">
          {experiences.map((exp, idx) => (
            <div key={idx} className={`t-item ${idx === 0 ? 'open' : ''}`}>
              <div className="t-date">{exp.period}</div>
              <div className="t-dot"></div>
              <div className="t-body">
                <h3>{exp.title}</h3>
                <div className="t-org mono">{exp.company}</div>
                <div className="t-desc">{exp.description}</div>
                <div className="t-toggle">
                  Read more{' '}
                  <svg width="10" height="10" viewBox="0 0 10 10">
                    <path d="M1 3l4 4 4-4" stroke="currentColor" strokeWidth="1.5" fill="none" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

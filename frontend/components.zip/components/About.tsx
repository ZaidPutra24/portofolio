import React from 'react';

export default function About() {
  return (
    <section id="about">
      <div className="wrap">
        <div className="sec-head">
          <div><div className="eyebrow">About</div><h2 style={{ marginTop: '8px' }}>Bridging the gap between engineering and intelligent systems.</h2></div>
          <p>Grounded in full-stack architecture, focused on scalable backend APIs and modern web interfaces.</p>
        </div>
        <div className="about-grid">
          <div className="bio">
            <p>I started with a deep fascination for clean code and robust systems — building APIs, databases, and structured backends. That foundation naturally expanded into <strong>integrating AI models, vector databases, and responsive frontends.</strong></p>
            <p>Today I focus on building complete digital solutions that are lightning fast, elegant, and maintainable. I care deeply about architecture, user experience, and delivering software that truly works.</p>
            <div className="stack-row">
              <span className="stack-chip">PYTHON</span>
              <span className="stack-chip">FASTAPI</span>
              <span className="stack-chip">NEXT.JS</span>
              <span className="stack-chip">TYPESCRIPT</span>
              <span className="stack-chip">TAILWIND</span>
              <span className="stack-chip">POSTGRESQL</span>
              <span className="stack-chip">DOCKER</span>
              <span className="stack-chip">GIT</span>
            </div>
          </div>
          <div className="stat-grid">
            <div className="stat"><div className="num">20+</div><div className="lbl">Projects completed</div></div>
            <div className="stat"><div className="num">100%</div><div className="lbl">Commitment</div></div>
            <div className="stat"><div className="num">5+</div><div className="lbl">Tech stacks mastered</div></div>
            <div className="stat"><div className="num">99.9%</div><div className="lbl">System reliability</div></div>
          </div>
        </div>
      </div>
    </section>
  );
}
